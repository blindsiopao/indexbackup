Thank you for downloading Ambitsek.
Ambitsek is a simple looking and very readable "small caps" style cross-platform bitmap font.


1)
This font is optimized to 8px size with no anti-aliasing. It contains an almost complete character
set (uppercase and "lowercase" letters, accented characters, punctuation, signs, symbols, arrows,
elements etc.), includes Western, Central and Eastern European and also basic Greek chars. As I
mentioned above, it's a "small caps" style font: it contains "lowercase" and uppercase chars too
(i.e. caps and larger caps), but if you want, you can use only the uppercase or only the lowercase
letters, as you like it.

2)
This font is free for personal and commercial use - provided "as is" with no warranties of any kind.
You may redistribute it but only for free and in this unmodified form - although you may modify it
for your own (personal or commercial) use.

3)
Finally, keep in mind the hungarian saying: "Iskális fiskális, aki kakál, pisál is."
(Putting into english: "Allyhoo ballyhoo, who is shitting's pissing, too.")


Again, thanks for downloading this font, I hope you will enjoy it.
And if you have time, watch this video, please: http://www.pestylaszlo.eu/index_eng.html

Best wishes,
Ambrus Weishappel
